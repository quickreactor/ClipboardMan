function c (codes) {
    var codesArray =[];
    var codeOutput = '';
    if (codes.length > 1) {
       codesArray =  codes.split(',');
    } else {
        codesArray = codes.split('');
    }
       
   codesArray.forEach((e,i) => {
      if (i > 0) {
        codeOutput += ', ';
      }
      switch(e) {
          case 'u':
            codeOutput += 'added unit number';
            break;
          case 'n':
            codeOutput += 'no unit number';
            break;
          case 'w':
            codeOutput += 'wrong suburb';
            break;
      }
   });
    copy(codeOutput);
}